<?php

namespace App\Controller;

use App\Core\View;

class Global{


	public function defaultAction(){
	

		$view = new View("home");


	}


}