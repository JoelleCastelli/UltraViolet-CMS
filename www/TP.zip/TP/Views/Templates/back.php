<!DOCTYPE html>
<html lang="FR">
<head>
	<title>Template de BACK</title>
	<meta name="description" content="ceci est la description de ma page">
</head>
<body>
	<header>
		<h1>Template du back</h1>
	</header>

	<!-- intégration de la vue -->

</body>
</html>