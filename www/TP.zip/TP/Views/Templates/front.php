<!DOCTYPE html>
<html lang="FR">
<head>
	<title>Template de FRONT</title>
	<meta name="description" content="ceci est la description de ma page">
</head>
<body>
	<header>
		<h1>Template du front</h1>
	</header>

	<!-- intégration de la vue -->
	<?php include $this->view ;?>

</body>
</html>