<section>
	<h2>Vue admin</h2>
</section>