<section>
	<h2>Welcome <?= $pseudo;?></h2>
	<small>Vous avez <?= $age;?> ans et votre email c'est <?= $email ?></small>
</section>




<?php for ($i=0; $i < 10; $i++):?>
	<b>test</b>
<?php endfor;?>