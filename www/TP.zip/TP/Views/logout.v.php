<section>
	<h2>Vue logout</h2>
</section>