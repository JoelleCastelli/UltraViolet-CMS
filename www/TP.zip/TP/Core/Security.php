<?php

namespace App\Core;

class Security
{

	public function isConnected(){
		return false;
	}

}